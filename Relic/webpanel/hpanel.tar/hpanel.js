const express = require('express');
const os = require('os');
const fs = require('fs');
const path = require('path');
const cors = require('cors');
const { exec } = require('child_process');

const app = express();
const PORT = 2000;
const IPSET_FILE_PATH = '/opt/etc/AdGuardHome/ipset.conf';
const SERVICES_URL = "https://github.com/Ground-Zerro/DomainMapper/raw/refs/heads/main/platformdb";
const SCRIPT_FILE_PATHS = [
    '/opt/etc/ndm/ifstatechanged.d/010-bypass-table.sh',
    '/opt/etc/ndm/ifstatechanged.d/011-bypass6-table.sh',
    '/opt/etc/ndm/netfilter.d/010-bypass.sh',
    '/opt/etc/ndm/netfilter.d/011-bypass6.sh',
];

// Enable CORS for all routes
app.use(cors());
app.use(express.static('/opt/etc/HydraRoute/public'));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve the index.html
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});


////////////////// ipset.html //////////////////

// Function to load existing domains for /load and /load-from-github routes
function loadExistingDomains() {
    if (fs.existsSync(IPSET_FILE_PATH)) {
        const data = fs.readFileSync(IPSET_FILE_PATH, 'utf8');
        return new Set(
            data.split(/\r?\n/)
                .map(line => line.split('/')[0].trim())
                .filter(Boolean)
        );
    }
    return new Set();
}

// Reading and outputting existing domains
app.get('/load', (req, res) => {
    const existingDomains = Array.from(loadExistingDomains());
    res.send(existingDomains.join('\n'));
});

// Save ipset entries
app.post('/save', (req, res) => {
    const { ipset_content, protocols } = req.body;

    // Checking for data availability
    if (!ipset_content) {
        return res.status(400).send('No data to save.');
    }

    // Determining whether to use "bypass6"
    const ipv6Enabled = protocols && protocols.includes("IPv6");
    const suffix = ipv6Enabled ? "/bypass,bypass6" : "/bypass";

    // Line cleaning and processing function
    const sanitizeLine = (line) => {
        // Replace ":" and ";", as well as spaces with commas
        let cleanedLine = line.replace(/[:;\s]+/g, ',');

        // Replace consecutive periods and commas with a single sign
        cleanedLine = cleanedLine.replace(/\.+/g, '.').replace(/,+/g, ',');

        // We remove characters other than letters, numbers, commas, hyphens and periods
        cleanedLine = cleanedLine.replace(/[^\w\-,.]+/g, '');

        // Removing special characters and punctuation marks at the end of a line
        cleanedLine = cleanedLine.replace(/[.,!?\/\\\- ]+$/, '');

        return cleanedLine;
    };

    // Breaking the text into lines and processing
    const lines = ipset_content.split(/\r?\n/).map(line => {
        const finalLine = sanitizeLine(line);

        // Adding the appropriate suffix to each line
        return finalLine ? finalLine + suffix : null;
    }).filter(Boolean); // Removing empty lines

    const contentToWrite = lines.join('\n');

    // Saving to file
    fs.writeFile(IPSET_FILE_PATH, contentToWrite, 'utf8', err => {
        if (err) {
            return res.status(500).send('Error while saving.');
        }

        // Restarting AdGuard Home after a successful save
        exec("/opt/etc/init.d/S99adguardhome restart", (error, stdout, stderr) => {
            if (error) {
                console.error(`Ошибка при перезапуске: ${error.message}`);
                return res.status(500).send('Error when restarting AdGuardHome.');
            }
            if (stderr) {
                console.error(`stderr: ${stderr}`);
            }
            res.send('Changes saved successfully!');
        });
    });
});

// Downloading a list of services and blacklists from GitHub
app.get('/load-services', async (req, res) => {
    try {
        const response = await fetch(SERVICES_URL);
        const text = await response.text();
        const lines = text.split(/\r?\n/).filter(Boolean);
        const services = lines.map(line => {
            // We are looking for the index of the sequence ": "
            const separatorIndex = line.indexOf(': ');
            if (separatorIndex !== -1) {
                const name = line.substring(0, separatorIndex).trim();
                const url = line.substring(separatorIndex + 2).trim(); // +2 to skip ": "
                return { name, url };
            }
            return null; // if there is no separator, then skip this line
        }).filter(service => service !== null); // Removing empty values

        res.json(services);
    } catch (error) {
        res.status(500).json({ error: 'Error loading list of services.' });
    }
});


// Loading and filtering domain names from GitHub services
app.post('/load-from-github', async (req, res) => {
    const { services } = req.body;

    if (!services || !services.length) {
        return res.status(400).send('There are no download services selected.');
    }

    try {
        const allDomains = new Set();

        // Helper function to remove BOM from text
        const removeBOM = (content) => {
            return content.startsWith('\uFEFF') ? content.slice(1) : content;
        };

        // Helper function for retrieving the root domain
        const getRootDomain = (domain) => {
            const parts = domain.split('.');
            return parts.length > 2 ? parts.slice(-2).join('.') : domain;
        };

        // Helper function for consolidating domains by root
        const consolidateDomains = (domains) => {
            const rootMap = new Map();
            
            domains.forEach(domain => {
                const rootDomain = getRootDomain(domain);
                if (!rootMap.has(rootDomain)) {
                    rootMap.set(rootDomain, new Set());
                }
                rootMap.get(rootDomain).add(domain);
            });

            return Array.from(rootMap.entries()).map(([root, subs]) =>
                subs.size > 1 ? root : Array.from(subs)[0]
            );
        };

        // Loading and merging domains from all services
        for (const serviceUrl of services) {
            const response = await fetch(serviceUrl);
            let content = await response.text();
            content = removeBOM(content);
            content.split(/\r?\n/)
                   .map(line => line.trim())
                   .filter(Boolean)
                   .forEach(domain => allDomains.add(domain));
        }

        const consolidatedDomains = consolidateDomains(Array.from(allDomains));
        const existingDomains = new Set(
            Array.from(loadExistingDomains())
                .flatMap(domain => domain.split(','))
                .map(domain => domain.trim())
                .filter(Boolean)
        );
        const newDomains = consolidatedDomains.filter(domain => !existingDomains.has(domain));

        if (newDomains.length > 0) {
            fs.appendFileSync(IPSET_FILE_PATH, '\n' + newDomains.join(',') + '/bypass');
        }

        res.send('Services have been added, don't forget to save changes.');
    } catch (error) {
        res.status(500).send('Error processing services.');
    }
});


////////////////// settings.html //////////////////

// Getting the current VPN interface
app.get('/vpn-interface', (req, res) => {
    try {
        const data = fs.readFileSync(SCRIPT_FILE_PATHS[0], 'utf8'); // Reading the first file
        const match = data.match(/\[\s*"\$system_name"\s*==\s*"(.+?)"\s*\]/);
        const vpnInterface = match ? match[1] : 'Not found';
        res.json({ vpnInterface });
    } catch (error) {
        res.json({ vpnInterface: 'Error' });
    }
});

// Getting a list of network interfaces
app.get('/network-interfaces', (req, res) => {
    const interfaces = os.networkInterfaces();
    const result = [];

    for (const [name, addresses] of Object.entries(interfaces)) {
        const ipv4 = addresses.filter(addr => addr.family === 'IPv4' && !addr.internal && addr.address !== '127.0.0.1').map(addr => addr.address);
        const ipv6 = addresses.filter(addr => addr.family === 'IPv6' && !addr.internal && addr.address !== '::1').map(addr => addr.address);

        if (ipv4.length > 0 || ipv6.length > 0) {
            result.push({ name, ipv4: ipv4.join(', '), ipv6: ipv6.join(', ') });
        }
    }

    res.json(result);
});

// Saving the new VPN interface in multiple files
app.post('/vpn-interface-save', (req, res) => {
    const { currentVpnInterface, newVpnInterface } = req.body;

    if (!newVpnInterface) {
        return res.status(400).json({ message: 'Error: interface not specified.' });
    }

    let successCount = 0;

    // Function to find and replace an interface in a file
    function replaceInterfaceInFile(filePath) {
        try {
            let data = fs.readFileSync(filePath, 'utf8');

            if (!data.includes(currentVpnInterface)) {
                return false;
            }

            // Direct replacement without changing other parts of the file
            const updatedData = data.replace(new RegExp(`\\b${currentVpnInterface}\\b`, 'g'), newVpnInterface);

            fs.writeFileSync(filePath, updatedData, 'utf8');
            return true;
        } catch (error) {
            return false;
        }
    }

    SCRIPT_FILE_PATHS.forEach(filePath => {
        if (replaceInterfaceInFile(filePath)) {
            successCount++;
        }
    });

    if (successCount > 0) {
        res.json({ message: `Установлен интерфейс: ${newVpnInterface}` });
    } else {
        res.status(500).json({ message: 'Error: Interface update failed.' });
    }
});


////////////////// adguard.html //////////////////

// Obtaining IP address br0
app.get('/br0ip', (req, res) => {
    res.json({ ip: br0IP });
});

// AdGuardHome status
app.get('/agh-status', (req, res) => {
    exec("/opt/etc/init.d/S99adguardhome status", (error, stdout, stderr) => {
        if (error) {
            return res.status(500).send('Failed to get status...');
        }

        const status = stdout.includes("alive") ? "Up and running" : "Stopped";
        res.send(status);
    });
});

// Restarting AdGuardHome
app.post('/agh-restart', (req, res) => {
    exec("/opt/etc/init.d/S99adguardhome restart", (error, stdout, stderr) => {
        if (error) {
            return res.status(500).send('Restart failed...');
        }

        res.send('Ok');
    });
});


////////////////// web server //////////////////

//web launch
function getBr0IP() {
    const interfaces = os.networkInterfaces();
    if (interfaces.br0) {
        const br0 = interfaces.br0.find(addr => addr.family === 'IPv4' && !addr.internal);
        return br0 ? br0.address : null;
    }
    return null;
}

const br0IP = getBr0IP();
if (!br0IP) {
    console.error("The IP address of interface br0 could not be determined.");
    process.exit(1);
}

app.listen(PORT, br0IP, () => {
    console.log(`Сервер запущен на http://${br0IP}:${PORT}`);
});

